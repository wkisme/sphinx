.. _foo_2:

foo/foo_2
=========
