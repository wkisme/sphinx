# -*- coding: utf-8 -*-

project = 'Sphinx ChangesBuilder tests'
copyright = '2007-2020 by the Sphinx team, see AUTHORS'
version = '0.6'
release = '0.6alpha1'
