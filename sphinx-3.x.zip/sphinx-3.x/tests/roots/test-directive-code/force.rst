force option
============

.. code:: python
   :force:

   not a python script!

.. code-block:: python
   :force:

   not a python script!

.. literalinclude:: error.inc
   :language: python
   :force:
