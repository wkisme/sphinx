void main()
{
  Example_Test t;
  t.example();
}
