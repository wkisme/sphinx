License
=======

Dot2tex is licensed under the MIT licence. It basically means that you can do whatever you want with it
as long as you keep the copyright license in all copies or substantial portions of the software. See :ref:`below <license_details>`
for details.

Authors
-------

.. include:: ../AUTHORS

.. _license_details:

The dot2tex license
-------------------

.. include:: ../LICENSE